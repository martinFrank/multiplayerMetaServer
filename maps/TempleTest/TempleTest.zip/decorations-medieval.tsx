<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="2021.01.13" name="decorations-medieval" tilewidth="32" tileheight="32" tilecount="1024" columns="16">
 <image source="decorations-medieval.png" width="512" height="2048"/>
</tileset>
